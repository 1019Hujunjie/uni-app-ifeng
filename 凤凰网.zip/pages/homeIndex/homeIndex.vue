<template>
	<view>
		<view class="logo">
			<image src="../../static/image/ifengLogo.png"></image>
		</view>
		<scroll-view scroll-x="true">
			<view 
				v-for="(item,index) in type" 
				:key="item.id"
				v-if="item.id<showNum"
				class="scrollItem"
			>
				{{item.content}}
			</view>
			<view class="iconImage" @click="clickArrowDown">
				<u-icon v-if="!isShow" class="icon" name="arrow-down" size="20"></u-icon>
				<u-icon v-else class="icon" name="arrow-up" size="20"></u-icon>
			</view>
		</scroll-view>
		
		<!-- 轮播图 -->
		<u-swiper 
			:list="imglist"
			mode="none"
			:effect3d="true"
			height="360"
			:title="true"
		></u-swiper>
		
		<!-- 新闻大标题 -->
		<view class="fontTitle">
			<view class="fontTitleLeft">
				<view class="fontWeight">{{isTitle?'今日要闻':'江苏要闻'}}</view>
				<view class="checkCity" @click="checkCity">切换城市</view>
			</view>
			<view>凤凰热榜</view>
		</view>
		
		<!-- 新闻内容 -->
		<view class="newTop">
			<view class="newTop-item"
				@click="clickNew"
				v-for="(item,index) in newlist" :key="item.id">
				<view class="newTitle">{{item.title}}</view>
				<view class="newContentBottom">
					<view class="newType" v-if="item.type != ''">{{item.type}}</view>
					<view class="newSource">{{item.source}}</view>
				</view>
			</view>
		</view>
		
		<view class="new">
			<view class="newItem"
				@click="clickNew"
				v-for="(item,index) in newlistTwo"
				v-if="item.id<showCount"
				:key="item.id">
				<view class="newLeft">
					<view class="newLeft-title">{{item.title}}</view>
					<view class="newLeft-comment"
					 v-if="item.comment != ''">
					{{item.comment}}评</view>
				</view>
				<view class="newRight">
					<image :src="item.image"></image>
				</view>
			</view>
		</view>
		<view class="gengduo" v-if="isButton">
			<view @click="showNew">展开更多</view>
			<u-icon name="arrow-down" size="20"></u-icon>
		</view>
		<!-- 返回顶部 -->
		<view>
			<u-back-top 
				:scroll-top="scrollTop" 
				top="100"
				bottom="300"
				icon="arrow-up"
				tips="顶部"
				mode="square">
			</u-back-top>
		</view>
		<view>
			<u-back-top 
				:scroll-top="scrollTop" 
				top="100"
				bottom="200"
				icon="arrow-down"
				tips="底部"
				mode="square">
			</u-back-top>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				scrollTop: 0,
				scrollTopBottom:0,
				isButton:true,
				showCount:6,
				isTitle:true,
				showNum:14,
				isShow:false,
				type:[
					{id:1,content:'资讯'},
					{id:2,content:'娱乐'},
					{id:3,content:'财经'},
					{id:4,content:'卫视'},
					{id:5,content:'军事'},
					{id:6,content:'科技'},
					{id:7,content:'体育'},
					{id:8,content:'小说'},
					{id:9,content:'房产'},
					{id:10,content:'汽车'},
					{id:11,content:'视频'},
					{id:12,content:'大风号'},
					{id:13,content:'时尚'},
					{id:14,content:'资讯'},
					{id:15,content:'娱乐'},
					{id:16,content:'财经'},
					{id:17,content:'卫视'},
					{id:18,content:'军事'},
					{id:19,content:'科技'},
					{id:20,content:'体育'},
					{id:21,content:'小说'},
					{id:22,content:'房产'},
					{id:23,content:'汽车'},
					{id:24,content:'视频'},
					{id:25,content:'大风号'},
					{id:26,content:'时尚'},
				],
				imglist:[
					{
						image:'/static/image/lunbo1.webp',
						title:'秦海路暗影油画感大片'
					},
					{
						image:'/static/image/lunbo2.webp',
						title:'俄国防部:已控制亚速钢铁厂地下设施2439名武装人员投降'
					},
					{
						image:'/static/image/lunbo3.webp',
						title:'为什么只有潮汕的牛肉丸能风靡全国?'
					},
				],
				newlist:[
					{
						id:1,
						title:"学习关键词|为有源头活水来",
						source:'央视新闻',
						type:'置顶'
					},
					{
						id:2,
						title:"治国必治边、治边先稳藏",
						source:'中国新闻网',
						type:'置顶'
					},
					{
						id:3,
						title:"把文艺创造写到民族复兴的历史上",
						source:'人民网',
						type:'置顶'
					},
					{
						id:4,
						title:"长风破浪会有时!政策定力护航中国经济",
						source:'新华网',
						type:''
					},
					{
						id:5,
						title:"为全面推进乡村振兴夯实筑牢战斗堡垒",
						source:'人民网',
						type:''
					},
					
				],
				newlistTwo:[
					{
						id:1,
						title:'支持婚俗改革江苏10部门出台全国首份省级层面集成式“政策包',
						image:'/static/image/tu1.webp',
						comment:'2'
					},
					{
						id:2,
						title:'江苏将长江江豚等84种野生种群列入红绝名录',
						image:'/static/image/tu2.webp',
						comment:''
					},
					{
						id:3,
						title:'总投资超1亿美元!香港协成国际香精香料生产基地项目落户南通',
						image:'/static/image/tu3.webp',
						comment:''
					},
					{
						id:4,
						title:'南通市委书记王晖:以强烈的使命担当推动新能源产业加快发展',
						image:'/static/image/tu4.webp',
						comment:''
					},
					{
						id:6,
						title:'群策群力构筑起铜墙铁壁!泰州市委常委会研究部署当前重点工作',
						image:'/static/image/tu5.webp',
						comment:'5'
					},
					{
						id:7,
						title:'支持婚俗改革江苏10部门出台全国首份省级层面集成式“政策包',
						image:'/static/image/tu1.webp',
						comment:'2'
					},
					{
						id:8,
						title:'江苏将长江江豚等84种野生种群列入红绝名录',
						image:'/static/image/tu2.webp',
						comment:''
					},
					{
						id:9,
						title:'总投资超1亿美元!香港协成国际香精香料生产基地项目落户南通',
						image:'/static/image/tu3.webp',
						comment:''
					},
					{
						id:10,
						title:'南通市委书记王晖:以强烈的使命担当推动新能源产业加快发展',
						image:'/static/image/tu4.webp',
						comment:''
					},
					{
						id:5,
						title:'群策群力构筑起铜墙铁壁!泰州市委常委会研究部署当前重点工作',
						image:'/static/image/tu5.webp',
						comment:'5'
					}
				]
			}
		},
		onPageScroll(e) {
			// console.log(e)
			this.scrollTop = e.scrollTop;
		},
		onLoad(e) {
			// console.log(e)
			// uni.getSystemInfo({
			// 	success:res=>{
			// 		this.scrollTopBottom = res.windowHeight
			// 		// console.log(res.windowHeight)
			// 	}
			// })
		},
		methods: {
			clickArrowDown(){
				this.isShow = !this.isShow
				if(this.isShow){
					this.showNum = this.type.length
				}else{
					this.showNum = 14
				}
			},
			checkCity(){
				this.isTitle = !this.isTitle
			},
			showNew(){
				this.showCount = this.newlistTwo.length
				this.isButton = false
			},
			clickNew(){
				uni.navigateTo({
					url:'noImageNew'
				})
			},
			clickNewTwo(){
				uni.navigateTo({
					url:'imageNew'
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.logo{
		margin: 20rpx;
		width: 230rpx;
		height: 80rpx;
	}
	.logo image{
		width: 100%;
		height: 100%;
	}
	.scrollItem{
		font-size: 28rpx;
		display: inline-block;
		width: 100rpx;
		text-align: center;
		height:60rpx;
		line-height: 60rpx;
	}
	.icon{
		display: inline-block;
		width: 100rpx;
		height: 38rpx;
		text-align: center;
	}
	.iconImage{
		display: inline-block;
		width: 100rpx;
		height: 68rpx;
		line-height: 38rpx;
	}
	.iconImage .icon{
		margin-left: 30rpx;
	}
	.swiper{
		margin-top: 20rpx;
		width: 100%;
		height: 380rpx;
	}
	.swiper-item{
		width: 100%;
		height: 100%;
	}
	.swiper-item image{
		// border-radius: 20rpx;
		width: 100%;
		height: 100%;
	}
	.fontTitle{
		margin: 20rpx 20rpx;
		display: flex;
		justify-content: space-between;
		font-size: 32rpx;
	}
	.fontTitleLeft{
		display: flex;
	}
	.fontTitleLeft .checkCity{
		color: #2B85E4;
		font-size: 30rpx;
	}
	.fontWeight{
		font-weight: bold;
		margin-right: 40rpx;
	}
	.newTop{
		border-bottom: 1px solid #e7e7e7;
		margin: 20rpx 20rpx;
	}
	.newTop-item{
		margin: 20rpx 0;
	}
	.newTitle{
		font-size: 38rpx;
		letter-spacing:1px ;
	}
	.newContentBottom{
		display: flex;
		font-size:24rpx ;
	}
	.newContentBottom .newType{
		color: red;
		margin-right: 30rpx;
	}
	.newSource{
		color: #999;
	}
	
	.new{
		margin: 20rpx 20rpx;
	}
	.newItem{
		display: flex;
		justify-content: space-between;
		margin: 20rpx 0;
	}
	.newLeft{
		margin: 0 10rpx;
		flex: 3;
		display: flex;
		flex-direction: column;
		justify-content: space-around;
	}
	.newLeft-title{
		font-size: 34rpx;
	}
	.newLeft-comment{
		font-size: 26rpx;
		color: #999;
	}
	.newRight{
		flex: 1;
	}
	.newRight image{
		width: 224rpx;
		height: 150rpx;
		border-radius: 10rpx;
	}
	.gengduo{
		font-size: 32rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		border-bottom: 1px solid #e7e7e7;
		border-top:1px solid #e7e7e7 ;
		padding: 20rpx 0;
	}
</style>
