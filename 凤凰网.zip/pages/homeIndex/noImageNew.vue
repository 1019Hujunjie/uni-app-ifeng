<template>
	<view class="marginBox">
		<u-toast ref="uToast"></u-toast>
		<!-- 新闻内容 -->
		<u-navbar title="资讯频道">
			<image class="logoImage" src="../../static/image/logo.png"></image>
			<u-icon class="zhuanfa" name="zhuanfa" size="44" color="#999"></u-icon>
		</u-navbar>
		<view>
			<view class="title">{{list.title}}</view>
			<view class="titleTop">
				<view class="timeLeft">
					<view class="timeSource">{{list.source}}</view>
					<view class="time">{{list.time}}</view>
				</view>
				<view class="fontBig" @click="changFont">字体:{{font?'小':'大'}}</view>
			</view>
			<view :class="font ? 'titleContentTwo':'titleContent'" v-html="list.content"></view>
			<image class="titleContentImage" :src="list.image"></image>
			<view :class="font ? 'titleContentTwo':'titleContent'" v-html="list.contentTwo"></view>
			<view class="footer">
				<view>总监制 | 钱蔚王姗姗</view>
				<view>监制 | 张鸥</view>
				<view>制片人 丨 兴来</view>
				<view>编辑 | 程昱</view>
				<view>视觉 丨 江雨航</view>
				<view>校对 丨 杨彩云</view>
				<view>总监制 | 钱蔚王姗姗</view>
				<view>总监制 | 钱蔚王姗姗</view>
			</view>
			</view>
			<view class="compile">
				<view>责任编辑：杜震 PX287</view>
				<view class="compileRight">
					<u-icon name="warning" size="30"></u-icon>
					<view>举报</view>
				</view>
			</view>
			
			<!-- 热门评论 -->
			<view class="hotComment">
				热门评论
			</view>
			
			<!-- 评论内容 -->
			<view class="comment">
				<view class="commentItem"
					v-for="(item,index) in headlist"
					:key="item.id">
					<u-avatar :src="item.image"></u-avatar>
					<view class="commentRight">
						<view class="commentRightTop">
							<view>{{item.name}}</view>
							<view>
								{{item.give}}<u-icon name="heart" size="30"></u-icon>
							</view>
						</view>
						<view>{{item.content}}</view>
						<view class="commentRightBottom">{{item.add}} {{item.time}}</view>
					</view>
				</view>
				<view class="publish">
					<textarea 
						class="textarea" 
						placeholder="写评论"
						v-model.trim="commentTitle">
						
					</textarea>
						<u-search
						shape="square"
						placeholder=""
						:disabled="true"
						search-icon="chat"
						action-text="发表评论"
						height="80"
						:action-style="actionStyle"
						@custom="clickSearch">
						</u-search>
				</view>
				<view class="commentBottom">
					<view>查看全部89条评论</view>
					<u-icon name="arrow-right" size="20" color="#999"></u-icon>
				</view>
			</view>
			<!-- 返回顶部 -->
			<view>
				<u-back-top 
					:scroll-top="scrollTop" 
					top="100"
					bottom="300"
					icon="arrow-up"
					tips="顶部"
					mode="square">
				</u-back-top>
			</view>
		</view>
	</view>
</template>

<script>
	export default{
		data(){
			return{
				scrollTop:0,
				font:false,
				commentTitle:'',
				actionStyle:{
					width:'160rpx',
					backgroundColor:'#f00',
					color:'#fff',
					lineHeight:'80rpx'
				},
				list:{
					title:'学习关键词|为有源头活水来',
					source:'央视新闻',
					time:'05-23 12:50',
					content:`<p>80年前的5月，在延安这片热土,人民的文艺之花次第开放。</p> <p>“我们的文学艺术都是为人民大众的，首先为工农兵的”</p>.<p>1942年5月，毛泽东同志主持召开延安文艺座谈会，鲜明指出文艺要为最广大的人民大众服务。</p><p>延安文艺座谈会校准了革命文艺的创作方向，激发了文艺工作者的创作热情，开启了人民文艺的新纪元。</p><p>党的十八大以来，我国文艺事业呈现出繁荣发展的蓬勃景象。</p>`,
					image:'/static/image/noimage1.png',
					contentTwo:`<p>习近平总书记引用毛泽东同志的话指出,“在过了几十年之后来看中国人民民主革命的胜利，就会使人们感觉那好像只是一出长剧的一个短小的序幕。剧是必须从序幕开始的，但序幕还不是高潮。</p><p>拉开序幕的历史长剧，正渐入佳境。</p><p>中国文艺事业也是如此。</p><p>坚持文艺为人民，广大文艺工作者将创作出更多无愧于时代、无愧于人民、无愧于民族的优秀作品。复兴之路上，必将有更加壮丽多彩的文艺风景。</p>`
				},
				headlist:[
					{
						id:1,
						image:'/static/image/head.jpg',
						name:'我不叫陈书君',
						content:'一个时代的画卷，底色是人心；一个民族的复兴，关键在精神。',
						add:'江苏',
						time:'5小时前',
						give:10
					},{
						id:2,
						image:'/static/image/head2.jpg',
						name:'莲花一支',
						content:'依法依规！点赞',
						add:'湖南',
						time:'1小时前',
						give:6
					},
				]
			}
		},
		onPageScroll(e){
			this.scrollTop = e.scrollTop
		},
		methods:{
			clickSearch(){
				if(this.commentTitle == ''){
					this.refs.uToast.show({
						title: '发表评论不能为空',
						type: 'error',
					})
				}else{
					this.headlist.push({
						id:this.headlist[this.headlist.length]+1,
						image:'/static/image/head2.jpg',
						name:'莲花一支',
						content:this.commentTitle,
						add:'江苏',
						time:'刚刚发布',
						give:0
					})
				}
			},
			changFont(){
				this.font = !this.font
			}
		}
	}
</script>

<style lang="scss" scoped>
	.marginBox{
		margin: 0 20rpx;
	}
	.logoImage{
		width: 44rpx;
		height: 44rpx;
	}
	.zhuanfa{
		position: fixed;
		top: 22rpx;
		right: 20rpx;
	}
	.title{
		font-size: 44rpx;
		text-align: center;
		font-weight: bold;
	}
	.titleTop{
		margin: 30rpx 0;
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
	.timeSource{
		font-size: 28rpx;
	}
	.time{
		font-size: 24rpx;
		color: #999;
	}
	.fontBig{
		padding: 10rpx;
		border-radius: 30rpx;
		border: 2rpx solid red;
		color: red;
		font-weight: bold;
	}
	.titleContent{
		letter-spacing: 1.20px;
		font-size: 36rpx;
		line-height:70rpx;
	}
	.titleContentTwo{
		letter-spacing: 1.20px;
		font-size: 32rpx;
		line-height:70rpx;
	}
	.titleContentImage{
		width: 710rpx;
		height: 1200rpx;
	}
	.footer{
		font-size: 36rpx;
		// height: 80rpx;
		line-height: 80rpx;
	}
	.compile{
		display: flex;
		justify-content: space-between;
		border-bottom: 1px solid #e7e7e7;
		padding-bottom: 20rpx;
	}
	.compile view:nth-child(1){
		color: #999;
		font-size: 30rpx;
	}
	.compile .compileRight{
		display: flex;
		margin-right: 30rpx;
		
	}
	.hotComment{
		margin: 100rpx 0 50rpx 0; 
		font-size: 38rpx;
		font-weight: bold;
		text-align: center;
	}
	.commentItem{
		display: flex;
		margin: 20rpx 0;
	}
	.commentItem u-avatar{
		flex: 1;
	}
	.commentRight{
		flex: 3;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		padding-left: 30rpx;
	}
	.commentRightTop{
		display: flex;
		justify-content: space-between;
		margin-bottom: 20rpx;
	}
	.commentRightBottom{
		color: #999;
		font-size: 24rpx;
		margin-top: 20rpx;
	}
	.textarea{
		border: 1px solid #e7e7e7;
		width: 710rpx;
		height: 270rpx;
		padding-top: 10rpx;
		text-indent: .5em;
		
	}
	.textarea:hover{
		border: 1px solid #000;
	}
	.commentBottom{
		margin: 30rpx 0;
		padding-bottom: 30rpx;
		display: flex;
		justify-content: center;
	}
</style>
